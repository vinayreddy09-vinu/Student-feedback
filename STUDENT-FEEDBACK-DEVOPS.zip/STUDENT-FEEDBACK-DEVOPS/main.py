
from collections.abc import Mapping
from flask import Flask, render_template, request, redirect
import csv
main = Flask(__name__)

@main.route("/")
def index():
    return render_template("index.html")

@main.route("/submit", methods=["POST"])
def submit():
    name = request.form["name"]
    subject = request.form["subject"]
    rating = request.form["rating"]
    comments = request.form["comments"]
    with open("feedback.csv", "a", newline="") as f:
        writer = csv.writer(f)
        writer.writerow([name, subject, rating, comments])
    return redirect("/summary")

@main.route("/summary")
def summary():
    feedbacks = []
    try:
        with open("feedback.csv", "r") as f:
            reader = csv.reader(f)
            feedbacks = list(reader)
    except FileNotFoundError:
        pass
    return render_template("summary.html", feedbacks=feedbacks)

if __name__ == "__main__":
    main.run(host='0.0.0.0', port=3000)

